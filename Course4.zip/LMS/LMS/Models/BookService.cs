﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LMS.Models
{
    public class BookService
    {
        /// <summary>
        /// 取得DB連線字串
        /// </summary>
        /// <returns></returns>
        private string GetDBConnectionString()
        {
            return System.Configuration.ConfigurationManager.ConnectionStrings["DBConn"].ConnectionString.ToString();
        }
        /// <summary>
        /// 新增借閱資料
        /// </summary>
        /// <param name="book"></param>
        /// <returns>書籍編號</returns>
        public int InsertBook(Models.Book book)
        {
            string sql = @" INSERT INTO BOOK_DATA
						 (
							 BOOK_NAME, BOOK_AUTHOR,BOOK_PUBLISHER,BOOK_NOTE,BOOK_BOUGHT_DATE,BOOK_CLASS_ID,BOOK_STATUS
						 )
						VALUES
						(
							 @BookName,@BookAuthor, @BookPublisher,@BookNote,@BookBoughtDate,@BookCategory,'A'
						)
                        Select SCOPE_IDENTITY()";
            int BookId;
            using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.Add(new SqlParameter("@BookName", book.BookName));
                cmd.Parameters.Add(new SqlParameter("@BookAuthor", book.BookAuthor));
                cmd.Parameters.Add(new SqlParameter("@BookPublisher", book.BookPublisher));
                cmd.Parameters.Add(new SqlParameter("@BookNote", book.BookNote));
                cmd.Parameters.Add(new SqlParameter("@BookBoughtDate", book.BookBoughtDate));
                cmd.Parameters.Add(new SqlParameter("@BookCategory", book.BookCategory));
                BookId = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();
            }
            return BookId;
        }

        /// <summary>
        /// 刪除客戶
        /// </summary>
        public void DeleteBookById(string BookId)
        {            
            try
            {
                //string checkstatus = "SELECT * FROM BOOK_DATA WHERE BOOK_STATUS = 'B'";
                string sql = "Delete FROM BOOK_DATA Where BOOK_ID=@BookId";
                //引用SqlConnection物件連接資料庫  GetDBConnectionString()是剛開始建立的連接字串
                using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
                {
                    conn.Open(); //開啟資料庫
                        //SqlCommand(String, SqlConnection)使用查詢的文字和 SqlConnection 初始化 SqlCommand 類別的新執行個體
                        //(string)代表詢的文字 ; SqlConnection，代表 SQL Server 執行個體的連接。
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.Add(new SqlParameter("@BookId", BookId));
                    cmd.ExecuteNonQuery();
                    //SqlCommand check = new SqlCommand(checkstatus, conn);
                    //int count = check.Parameters.Count;
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// 依照條件取得借閱資料
        /// </summary>
        /// <returns></returns>
        public List<Models.Book> GetBookByCondtioin(Models.BookSearchArg arg)
        {
            DataTable dt = new DataTable();
            string sql = @"SELECT C.BOOK_CLASS_NAME ,B.BOOK_NAME ,
                                  CONVERT(VARCHAR(10),B.BOOK_BOUGHT_DATE,111) As BOOK_BOUGHT_DATE,
                                  E.CODE_NAME ,D.USER_ENAME,B.BOOK_ID ,E.CODE_ID
                           FROM BOOK_DATA B
							   LEFT JOIN BOOK_LEND_RECORD A 
									ON A.BOOK_ID = B.BOOK_ID
							   LEFT JOIN BOOK_CLASS C 
		                            ON B.BOOK_CLASS_ID = C.BOOK_CLASS_ID
							   LEFT JOIN BOOK_CODE E 
		                            ON B.BOOK_STATUS = E.CODE_ID AND E.CODE_TYPE = 'BOOK_STATUS'
	                           LEFT JOIN  MEMBER_M D
		                            ON D.USER_ID = A.KEEPER_ID
                           Where (B.BOOK_NAME LIKE ('%' + @BookName + '%')or @BookName='')AND
                                 (B.BOOK_CLASS_ID = @BookCategory or @BookCategory='' )AND
                                 (D.USER_ENAME = @UserEname or @UserEname='')AND
                                 (E.CODE_ID = @BookStatus or @BookStatus='')
                           ";
            using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.Add(new SqlParameter("@BookName", arg.BookName == null ? string.Empty : arg.BookName));
                cmd.Parameters.Add(new SqlParameter("@BookCategory", arg.BookCategory == null ? string.Empty : arg.BookCategory));
                cmd.Parameters.Add(new SqlParameter("@UserEname", arg.UserEname == null ? string.Empty : arg.UserEname));
                cmd.Parameters.Add(new SqlParameter("@BookStatus", arg.BookStatus == null ? string.Empty : arg.BookStatus));
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(cmd);
                sqlAdapter.Fill(dt);
                conn.Close();
            }
            return this.MapBookDataToList(dt);
        }

        /// <summary>
        /// Map資料進List
        /// </summary>
        /// <param name="bookData"></param>
        /// <returns></returns>

        private List<Models.Book> MapBookDataToList(DataTable bookData)
        {
            List<Models.Book> result = new List<Book>();
            foreach (DataRow row in bookData.Rows)
            {
                result.Add(new Book()
                {
                    BookId = (int)row["BOOK_ID"],
                    BookName = row["BOOK_NAME"].ToString(),
                    BookCategory = row["BOOK_CLASS_NAME"].ToString(),
                    UserEname = row["USER_ENAME"].ToString(),
                    BookStatus = row["CODE_NAME"].ToString(),
                    BookBoughtDate = row["BOOK_BOUGHT_DATE"].ToString(),
                    BookStatusId = row["CODE_ID"].ToString(),
                    //BookAuthor = row["BookAuthor"].ToString(),
                    //BookPublisher = row["BookPublisher"].ToString(),
                    //BookNote = row["BookNote"].ToString()
                    //CONVERT(VARCHAR(10),B.BOOK_BOUGHT_DATE,111)
                });
            }
            return result;
        }
    }
}