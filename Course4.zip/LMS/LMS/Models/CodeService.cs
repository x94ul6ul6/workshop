﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LMS.Models
{
    public class CodeService
    {
        /// <summary>
        /// 取得DB連線字串
        /// </summary>
        /// <returns></returns>
        private string GetDBConnectionString()
        {
            return
                System.Configuration.ConfigurationManager.ConnectionStrings["DBConn"].ConnectionString.ToString();
        }

        /// <summary>
        /// 取得圖書類別資料
        /// </summary>
        /// <returns></returns>
        public List<SelectListItem> GetBookCategory(string bookCategory)
        {
            DataTable dt = new DataTable();
            string sql = @"Select BOOK_CLASS_NAME As BookCategory ,
                                  BOOK_CLASS_ID As BookClassId
                           FROM BOOK_CLASS";
            //WHERE BOOK_CLASS_NAME != @BookCategory
            using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.Add(new SqlParameter("@BookCategory", bookCategory));
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(cmd);

                sqlAdapter.Fill(dt);
                conn.Close();
            }
            return this.MapCategoryData(dt);
        }
        /// <summary>
        /// 取得借閱人資料
        /// </summary>
        /// <returns></returns>
        public List<SelectListItem> GetUserEname(string userEname)
        {
            DataTable dt = new DataTable();
            string sql = @"Select USER_ENAME As UserEname 
                           FROM MEMBER_M";
            //WHERE BOOK_CLASS_NAME != @BookCategory
            using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.Add(new SqlParameter("@UserEname", userEname));
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(cmd);

                sqlAdapter.Fill(dt);
                conn.Close();
            }
            return this.MapUserEnameData(dt);
        }
        /// <summary>
        /// 取得借閱狀態資料
        /// </summary>
        /// <returns></returns>
        public List<SelectListItem> GetBookStatus(string bookStatus)
        {
            DataTable dt = new DataTable();
            string sql = @"SELECT E.CODE_NAME As BookStatus, E.CODE_ID AS BookStatusID
                           FROM BOOK_CODE E
                           WHERE E.CODE_TYPE = 'BOOK_STATUS'";
            //WHERE BOOK_CLASS_NAME != @BookCategory
            using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.Add(new SqlParameter("@BookStatus", bookStatus));
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(cmd);

                sqlAdapter.Fill(dt);
                conn.Close();
            }
            return this.MapBookStatusData(dt);
        }


        /// <summary>
        /// Maping 代碼資料
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private List<SelectListItem> MapCategoryData(DataTable dt)
        {
            List<SelectListItem> result = new List<SelectListItem>();
            foreach (DataRow row in dt.Rows)
            {
                result.Add(new SelectListItem()
                {
                    Text = row["BookCategory"].ToString(),
                    Value = row["BookClassId"].ToString()
                });
            }
            return result;
        }
        private List<SelectListItem> MapUserEnameData(DataTable dt)
        {
            List<SelectListItem> result = new List<SelectListItem>();
            foreach (DataRow row in dt.Rows)
            {
                result.Add(new SelectListItem()
                {
                    Text = row["UserEname"].ToString(),
                    Value = row["UserEname"].ToString()
                });
            }
            return result;
        }
        private List<SelectListItem> MapBookStatusData(DataTable dt)
        {
            List<SelectListItem> result = new List<SelectListItem>();
            foreach (DataRow row in dt.Rows)
            {
                result.Add(new SelectListItem()
                {
                    Text = row["BookStatus"].ToString(),
                    Value = row["BookStatusID"].ToString()
                });
            }
            return result;
        }


    }
}