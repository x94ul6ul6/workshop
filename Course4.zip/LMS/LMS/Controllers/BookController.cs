﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LMS.Controllers
{
    public class BookController : Controller
    {
        Models.CodeService codeService = new Models.CodeService();
        /// <summary>
        /// 借閱紀錄查詢
        /// </summary>
        /// <returns></returns>
        // GET: Book
        public ActionResult Index()
        {
            ViewBag.BookCategoryCodeData = this.codeService.GetBookCategory("CATEGORY");
            ViewBag.BookUserEnameCodeData = this.codeService.GetUserEname("USERENAME");
            ViewBag.BookStatusCodeData = this.codeService.GetBookStatus("STATUS");
            return View();
        }
        /// <summary>
        /// 借閱紀錄查詢(查詢)
        /// </summary>
        /// <returns></returns>
        [HttpPost()]
        public ActionResult Index(Models.BookSearchArg arg)
        {
            Models.BookService bookService = new Models.BookService();
            ViewBag.SearchResult = bookService.GetBookByCondtioin(arg);
            ViewBag.BookCategoryCodeData = this.codeService.GetBookCategory("CATEGORY");
            ViewBag.BookUserEnameCodeData = this.codeService.GetUserEname("USERENAME");
            ViewBag.BookStatusCodeData = this.codeService.GetBookStatus("STATUS");
            return View("Index");
        }

        /// <summary>
        /// 新增借閱紀錄畫面
        /// </summary>
        /// <returns></returns>
        [HttpGet()]
        public ActionResult InsertBook()
        {
            ViewBag.BookCategoryCodeData = this.codeService.GetBookCategory("CATEGORY");
            return View(new Models.Book());
        }
        /// <summary>
        /// 新增借閱紀錄
        /// </summary>
        /// <param name="book">hello</param>
        /// <returns></returns>
        [HttpPost()]
        public ActionResult InsertBook(Models.Book book)
        {
            ViewBag.BookCategoryCodeData = this.codeService.GetBookCategory("CATEGORY");
            if (ModelState.IsValid)
            {
                Models.BookService bookService = new Models.BookService();
                bookService.InsertBook(book);
                TempData["message"] = "存檔成功";
            }
            return View(book);
        }

        /// <summary>
        /// 刪除書籍紀錄
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        [HttpPost()]
        public JsonResult DeleteBook(string bookId)
        {
            try
            {
                Models.BookService BookService = new Models.BookService();
                BookService.DeleteBookById(bookId);
                return this.Json(true);
            }
            catch (Exception ex)
            {
                return this.Json(false);
            }
        }
    }
}